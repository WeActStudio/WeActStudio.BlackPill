./AT32_ISP_Console.sh
export LD_LIBRARY_PATH=$(pwd)
./AT32_ISP_Console -com --pn ttyACM0 --br 115200 --db 8 --pr EVEN --to 5 -p --dfap --depp -enspim --ft 2 --fs 16 --fda 1000000 --remap 1p -e --all -d --a 08400000 --fn /home/artery/test_binhex/test_256k.bin --v --o -usd --set --fn /home/artery/test_binhex/UserSystemData.bin -p --efap
